=== YCP Checkout Купить в 1 клик ===
Contributors: perfinn
Tags: yandex, ycp, checkout, marketplace, integration
Requires at least: 5.8
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Полная интеграция WooCommerce с Яндекс Чекаутом по протоколу YCP. Заказы из Яндекса автоматически создаются в WooCommerce.

== Description ==

Плагин реализует все 10 обязательных эндпоинтов протокола Yandex Commerce Protocol (YCP) v1:

* `GET  /api/v1/warehouses` — список складов магазина
* `POST /api/v1/checkout/basket/check` — проверка корзины (цены, наличие, габариты)
* `POST /api/v1/checkout/delivery/options` — варианты доставки
* `GET  /api/v1/checkout/delivery/pickup_points` — пункты выдачи
* `POST /api/v1/checkout` — создание сессии чекаута (резерв заказа)
* `POST /api/v1/checkout/placed` — заказ оплачен
* `POST /api/v1/checkout/cancel` — отмена сессии
* `GET  /api/v1/order` — статус доставки заказа
* `POST /api/v1/order/cancel` — отмена заказа
* `POST /api/v1/order/delivered` — заказ доставлен

Возможности:

* Bearer-токен авторизация (Authorization header или X-API-Key)
* Идемпотентность по session_id (один заказ = одна сессия)
* Автоматическое создание WooCommerce-заказа со статусом pending
* Маппинг товаров по SKU и WC ID
* Корректное письмо «Новый заказ» с актуальной суммой (через checkout-draft → pending)
* HPOS-совместимость (новое хранилище заказов WC)
* Лог последних 100 запросов в админке
* Поддержка габаритов товаров (по умолчанию 32×13×22 см / 850 г для расчёта доставки СДЭК)

== Installation ==

1. Загрузите плагин в `/wp-content/plugins/yandex-ycp-woo/` или установите через админку WP «Плагины → Добавить новый → Загрузить плагин».
2. Активируйте плагин.
3. Перейдите в `Инструменты → YCP Yandex Commerce`.
4. Вставьте Bearer-токен, полученный в кабинете Яндекс Чекаута.
5. Заполните данные склада (название, адрес, телефон).
6. Скопируйте URL endpoint-а и вставьте в поле «URL для API» в кабинете Яндекса.
7. Нажмите в кабинете Яндекса «Проверить подключение».

== Support ==

По техническим вопросам, ошибкам интеграции, кастомным доработкам и сопровождению пишите на:

**info@perfinn.ru**

Указывайте в письме версию WordPress, WooCommerce, версию плагина и фрагмент лога из «Инструменты → YCP Yandex Commerce → Лог последних запросов».

== Frequently Asked Questions ==

= Куда писать, если что-то не работает? =

info@perfinn.ru — техническая поддержка плагина.


= Что такое YCP? =

Yandex Commerce Protocol — это спецификация интеграции магазина с Яндекс Чекаутом, маркетплейсами Яндекса и Яндекс Маркетом. Документация: https://yandex.ru/support/merchants-ru-ycp/

= Где взять Bearer-токен? =

В кабинете Яндекс Чекаута: «Настройки интеграции → URL для API и токен доступа → Ваш токен API».

= Куда вставляется URL? =

В кабинете Яндекса в поле «URL для API» вставляется адрес вида `https://ваш-сайт.ru/ycp/`.

= Какой статус получают новые заказы? =

`pending` (Ожидает оплаты) при оплате online — после `/checkout/placed` переводится в `processing`. При оплате наложенным платежом сразу `processing`.

= Что делать, если в чекауте «Не удалось перейти к оплате»? =

Откройте `Инструменты → YCP Yandex Commerce → Лог последних запросов`. Найдите запись с типом `EXCEPTION` — там будет подробное сообщение об ошибке.

== Changelog ==

= 1.0.0 =
* Первый публичный релиз: все 10 эндпоинтов YCP v1, идемпотентность, HPOS-совместимость.
